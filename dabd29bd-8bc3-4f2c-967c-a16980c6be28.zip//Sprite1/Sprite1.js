/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume2", "./Sprite1/costumes/costume2.svg", {
        x: 23.30756208136677,
        y: 128.0824576996095,
      }),
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "go" }, this.whenIReceiveGo),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.BROADCAST, { name: "win" }, this.whenIReceiveWin),
    ];
  }

  *whenIReceiveGo() {
    this.stage.vars.xv = 0;
    this.stage.vars.yv = 0;
    while (true) {
      if (this.keyPressed("right arrow")) {
        this.stage.vars.xv++;
      }
      if (this.keyPressed("left arrow")) {
        this.stage.vars.xv--;
      }
      this.stage.vars.xv = this.toNumber(this.stage.vars.xv) * 0.9;
      this.x += this.toNumber(this.stage.vars.xv);
      if (this.touching(Color.rgb(0, 0, 0))) {
        this.y += 1;
        if (this.touching(Color.rgb(0, 0, 0))) {
          this.y += 1;
          if (this.touching(Color.rgb(0, 0, 0))) {
            this.y += 1;
            if (this.touching(Color.rgb(0, 0, 0))) {
              this.y += 1;
              if (this.touching(Color.rgb(0, 0, 0))) {
                this.y += 1;
                if (this.touching(Color.rgb(0, 0, 0))) {
                  this.x += this.toNumber(this.stage.vars.xv) * -1;
                  this.y -= 5;
                  if (this.keyPressed("up arrow")) {
                    if (this.compare(this.stage.vars.xv, 0) > 0) {
                      this.stage.vars.xv = -5;
                    } else {
                      this.stage.vars.xv = 5;
                    }
                    this.stage.vars.yv = 10;
                  } else {
                    this.stage.vars.xv = 0;
                  }
                }
              }
            }
          }
        }
      }
      this.stage.vars.yv--;
      this.y += this.toNumber(this.stage.vars.yv);
      if (this.touching(Color.rgb(0, 0, 0))) {
        this.y += this.toNumber(this.stage.vars.yv) * -1;
        this.stage.vars.yv = 0;
      }
      this.y -= 1;
      if (this.touching(Color.rgb(0, 0, 0))) {
        if (this.keyPressed("up arrow")) {
          this.stage.vars.yv = 15;
        }
      }
      this.y += 1;
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.broadcast("go");
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.touching(Color.rgb(255, 0, 0))) {
        this.goto(-225, -33);
        this.stage.vars.deaths++;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.watchers.secretRoomFinders.visible = false;
    while (true) {
      if (this.touching(Color.rgb(0, 27, 255))) {
        this.stage.costume = "backdrop21";
        this.stage.watchers.secretRoomFinders.visible = true;
        this.stage.vars.secretRoomFinders.push(/* no username */ "");
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    this.stage.costume = "backdrop1";
    this.stage.vars.deaths = 0;
    while (true) {
      if (this.touching(Color.rgb(47, 255, 0))) {
        yield* this.broadcastAndWait("win");
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.compare(this.stage.costumeNumber, 20) < 0) {
        if (this.touching("edge")) {
          this.stage.costumeNumber++;
          this.goto(-225, -33);
        }
      } else {
        null;
      }
      yield;
    }
  }

  *whenIReceiveWin() {
    this.stage.costume = "backdrop1";
  }
}
