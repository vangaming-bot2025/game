/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bat extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("bat-a", "./Bat/costumes/bat-a.svg", {
        x: 79.52013469042103,
        y: 60.022000000000006,
      }),
      new Costume("bat-b", "./Bat/costumes/bat-b.svg", {
        x: 38.316616728914994,
        y: 60.7,
      }),
      new Costume("bat-c", "./Bat/costumes/bat-c.svg", {
        x: 67.93875878178892,
        y: 65.701,
      }),
      new Costume("bat-d", "./Bat/costumes/bat-d.svg", { x: 29, y: 62 }),
    ];

    this.sounds = [new Sound("owl", "./Bat/sounds/owl.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.KEY_PRESSED, { key: "b" }, this.whenKeyBPressed),
    ];

    this.vars.bossHeath = 50;

    this.watchers.bossHeath = new Watcher({
      label: "Bat: Boss heath",
      style: "normal",
      visible: false,
      value: () => this.vars.bossHeath,
      x: 465,
      y: 137,
    });
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber === 21) {
        this.watchers.bossHeath.visible = true;
        this.visible = true;
        while (true) {
          this.costumeNumber++;
          yield* this.glide(1, this.random(-240, 240), this.random(-180, 180));
          yield;
        }
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.watchers.bossHeath.visible = false;
    this.vars.bossHeath = 50;
    while (true) {
      if (this.costumeNumber === 4) {
        if (this.touching(this.sprites["Sprite2"].andClones())) {
          this.vars.bossHeath--;
          yield* this.wait(0.1);
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toNumber(this.vars.bossHeath) === 0) {
        this.visible = false;
        this.goto(99999, 99999);
        this.stage.costume = "backdrop22";
      }
      yield;
    }
  }

  *whenKeyBPressed() {
    this.vars.bossHeath = 0;
  }
}
