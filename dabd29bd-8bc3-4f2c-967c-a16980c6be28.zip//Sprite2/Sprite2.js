/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite2/costumes/costume1.svg", {
        x: 104.5,
        y: 22,
      }),
    ];

    this.sounds = [new Sound("pop", "./Sprite2/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber === 20) {
        if (this.keyPressed("space")) {
          this.visible = true;
          this.goto(this.sprites["Sprite1"].x, this.sprites["Sprite1"].y);
          this.move(50);
        } else {
          this.visible = false;
          this.goto(999, 999);
        }
      } else {
        this.visible = false;
        this.goto(99999, 999);
      }
      yield;
    }
  }
}
