/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite4 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite4/costumes/costume1.svg", {
        x: 35,
        y: 65.5,
      }),
    ];

    this.sounds = [new Sound("pop", "./Sprite4/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Unlock" },
        this.whenIReceiveUnlock
      ),
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber === 20) {
        this.goto(220, -117);
        this.visible = true;
      } else {
        this.visible = false;
        this.goto(99999, 99999);
      }
      yield;
    }
  }

  *whenIReceiveUnlock() {
    while (true) {
      if (this.stage.costumeNumber === 20) {
        this.goto(5, 100);
        this.visible = false;
      } else {
        null;
      }
      yield;
    }
  }
}
